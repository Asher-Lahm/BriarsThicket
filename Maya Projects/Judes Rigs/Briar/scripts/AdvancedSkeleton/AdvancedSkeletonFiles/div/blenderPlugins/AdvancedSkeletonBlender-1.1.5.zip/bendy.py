"""Native curve-driven bendy limbs. No runtime handler or external solver."""
import re

import bpy
from mathutils import Matrix, Vector


def _constraint(owner, kind, rig, target, name):
    c = owner.constraints.new(kind)
    c.name = name
    c.target = rig
    c.subtarget = target
    if hasattr(c, "owner_space"):
        c.owner_space = "POSE"
        c.target_space = "POSE"
    return c


def _copy_constraint(source, owner):
    result = owner.constraints.new(source.type)
    for prop in source.bl_rna.properties:
        key = prop.identifier
        if key == "rna_type" or prop.is_readonly or prop.type == "COLLECTION":
            continue
        try:
            setattr(result, key, getattr(source, key))
        except (AttributeError, TypeError, ValueError):
            pass
    # POSE is available only after an armature target/subtarget is assigned.
    # RNA lists target_space before target; setting it in enumeration order
    # can fail and silently leave WORLD, applying the armature rotation twice.
    result.owner_space = source.owner_space
    result.target_space = source.target_space
    return result


def _copy_driver(rig, source, path):
    try:
        curve = rig.driver_add(path, source.array_index)
    except TypeError:
        curve = rig.driver_add(path)
    driver = curve.driver
    driver.type = source.driver.type
    driver.use_self = source.driver.use_self
    for old in source.driver.variables:
        var = driver.variables.new()
        var.name, var.type = old.name, old.type
        for target, original in zip(var.targets, old.targets):
            for key in ("id_type", "id", "data_path", "bone_target", "transform_type",
                        "transform_space", "rotation_mode"):
                try:
                    setattr(target, key, getattr(original, key))
                except (AttributeError, TypeError, ValueError):
                    pass
    driver.expression = source.driver.expression


def remove(context, rig):
    """Restore the saved solver inputs before an in-place Body rebuild."""
    prefix = "MCH_BendyBase_"
    mapping = {p.name: p.name[len(prefix):] for p in rig.pose.bones
               if p.name.startswith(prefix)}
    if not mapping:
        return
    controls = set(rig.get("as_bendy_controls", []))
    helpers = {p.name for p in rig.pose.bones if p.name.startswith("MCH_Bendy")}
    for helper, name in mapping.items():
        source, target = rig.pose.bones[helper], rig.pose.bones.get(name)
        if target is None:
            continue
        for c in list(target.constraints):
            target.constraints.remove(c)
        target.rotation_mode = source.rotation_mode
        target.matrix_basis = source.matrix_basis.copy()
        for c in source.constraints:
            _copy_constraint(c, target)
    drivers = list(rig.animation_data.drivers) if rig.animation_data else []
    for curve in drivers:
        match = re.match(r'pose\.bones\["([^"\\]+)"\]', curve.data_path)
        if match and match[1] in mapping:
            _copy_driver(rig, curve, curve.data_path.replace(
                f'pose.bones["{match[1]}"]', f'pose.bones["{mapping[match[1]]}"]', 1))
    for p in rig.pose.bones:
        for c in p.constraints:
            if getattr(c, "target", None) == rig and getattr(c, "subtarget", "") in mapping:
                c.subtarget = mapping[c.subtarget]
    for curve in list(rig.animation_data.drivers):
        match = re.match(r'pose\.bones\["([^"\\]+)"\]', curve.data_path)
        if match and match[1] in helpers | controls:
            rig.animation_data.drivers.remove(curve)
            continue
        for var in curve.driver.variables:
            for target in var.targets:
                if target.id == rig and target.bone_target in mapping:
                    target.bone_target = mapping[target.bone_target]
    for obj in list(bpy.data.objects):
        if obj.get("advanced_skeleton_role") == "BENDY_CURVE" and obj.parent == rig:
            data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if data.users == 0:
                bpy.data.curves.remove(data)
    context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    for b in rig.data.edit_bones:
        if b.parent and b.parent.name in mapping:
            matrix = b.matrix.copy()
            b.parent = rig.data.edit_bones[mapping[b.parent.name]]
            b.matrix = matrix
    for name in helpers | controls:
        b = rig.data.edit_bones.get(name)
        if b:
            rig.data.edit_bones.remove(b)
    bpy.ops.object.mode_set(mode="OBJECT")
    if "as_bendy_controls" in rig:
        del rig["as_bendy_controls"]


def build(context, rig, data, fk_controls, api):
    records = {c["name"]: c for c in data["rig"]["controls"]
               if c.get("type") in {"Bend", "BendMid"}
               and c.get("curveShapes")
               and not c.get("name", "").startswith(("BendExtra", "BendMidExtra"))}
    specs = [s for component in api._standard_twist_components(rig, fk_controls)
             for s in component if "Bend" + s[0] in records]
    if not specs:
        return 0

    # Preserve the already solved twist chains as independent mechanism input.
    # The original skin bones become curve outputs; control/IK attachments
    # continue to read these unbent inputs, avoiding a solver feedback loop.
    driven = {n for root, parts, end in specs for n in [root, *parts, end]}
    base = {n: "MCH_BendyBase_" + n for n in driven}
    parents = {n: rig.data.bones[n].parent.name if rig.data.bones[n].parent else ""
               for n in driven}
    rest = {n: rig.data.bones[n].matrix_local.copy() for n in driven}
    original_drivers = list(rig.animation_data.drivers) if rig.animation_data else []
    bpy.ops.object.mode_set(mode="EDIT")
    bones = rig.data.edit_bones

    def bone(name, matrix, parent=""):
        b = bones.get(name) or bones.new(name)
        b.parent = bones.get(parent)
        b.use_connect = False
        b.matrix = matrix
        b.length = 0.1
        b.use_deform = False
        return b

    for n in sorted(driven):
        b = bone(base[n], rest[n])
        b.length = bones[n].length
        b.inherit_scale = bones[n].inherit_scale
        b.use_local_location = bones[n].use_local_location
    for n in driven:
        bones[base[n]].parent = bones.get(base.get(parents[n], parents[n]))
        bones[base[n]].matrix = rest[n]
    for b in list(bones):
        if b.name not in driven and b.name not in base.values() and b.parent and b.parent.name in driven:
            if not b.use_deform:
                matrix = b.matrix.copy()
                b.parent = bones[base[b.parent.name]]
                b.matrix = matrix

    control_info = {}
    for root, parts, end in specs:
        stem, side = root.rsplit("_", 1)
        names = [n for n in records if n == "Bend" + root
                 or n == "BendMid" + root
                 or re.fullmatch(r"Bend" + re.escape(stem) + r"\d+_" + side, n)]
        a, z = rest[root].translation, rest[end].translation
        direction = z - a
        for name in names:
            matrix = api._maya_controller_matrix_to_blender(records[name])
            if matrix is None:
                continue
            matrix = api._maya_world_to_armature_rest(rig, matrix).normalized()
            t = max(0.0, min(1.0, (matrix.translation-a).dot(direction)/direction.length_squared))
            offset = "MCH_BendyOffset_" + name
            bone(offset, matrix)
            bone(name, matrix, offset)
            control_info[name] = (root, end, t, offset)

    # Create one weighted bind helper for every cubic-curve CV, and a path
    # sample/output pair per skin joint. Maya's simple case uses five CVs:
    # endpoint, 60/40 endpoint-mid, mid, 40/60 mid-end, endpoint.
    curves = []
    secondary = []
    end_handles = []
    for root, parts, end in specs:
        stem, side = root.rsplit("_", 1)
        start = f"Bend{stem}0_{side}"
        start = "BendMid" + root if "BendMid" + root in control_info else start
        start = start if start in control_info else base[root]
        end_stem, end_side = end.rsplit("_", 1)
        finish = "BendMid" + end if "BendMid" + end in control_info else f"Bend{end_stem}0_{end_side}"
        finish = finish if finish in control_info else base[end]
        end_matrix = rest[root].copy()
        end_matrix.translation = rest[end].translation
        handle = "MCH_BendyEnd_" + root
        bone(handle, end_matrix)
        end_handles.append((handle, root, finish))
        finish = handle
        master = "Bend" + root
        mids = sorted([n for n, info in control_info.items() if info[0] == root
                       and re.fullmatch(r"Bend" + re.escape(stem) + r"[1-9]\d*_" + side, n)],
                      key=lambda n: control_info[n][2]) or [master]
        if mids != [master]:
            cv_weights = [[(start, 1.0)], [(start, .6), (master, .4)],
                          [(master, 1.0)], [(master, .4), (finish, .6)], [(finish, 1.0)]]
            cv_points = [rest[root].translation.lerp(rest[end].translation, t)
                         for t in (0, 1/6, .5, 5/6, 1)]
            helpers = []
            for i, p in enumerate(cv_points):
                name = f"MCH_BendyMasterCV_{root}_{i}"
                bone(name, Matrix.Translation(p))
                helpers.append(name)
            for name in mids:
                bone("MCH_BendyMasterPath_" + name, Matrix.Identity(4))
            secondary.append((root, mids, cv_points, cv_weights, helpers))
        weights = [[(start, 1.0)], [(start, .6), (mids[0], .4)]]
        weights += [[(n, 1.0)] for n in mids]
        weights += [[(mids[-1], .4), (finish, .6)], [(finish, 1.0)]]
        # Greville abscissae of a uniform clamped cubic spline: this produces
        # an exactly straight, uniformly parameterized neutral curve.
        spans = len(weights) - 3
        knots = [0.0]*4 + [i/spans for i in range(1, spans)] + [1.0]*4
        points = [rest[root].translation.lerp(rest[end].translation,
                  sum(knots[i+1:i+4])/3) for i in range(len(weights))]
        cv_names = []
        for i, p in enumerate(points):
            name = f"MCH_BendyCV_{root}_{i}"
            bone(name, Matrix.Translation(p))
            cv_names.append(name)
        samples = []
        for n in [root, *parts, end]:
            name = f"MCH_BendyPath_{root}_{n}"
            bone(name, Matrix.Identity(4))
            samples.append(name)
        for n in [root, *parts]:
            bone("MCH_BendyResult_" + n, rest[n])
            bone("MCH_BendyScale_" + n, rest[n])
        curves.append((root, parts, end, points, weights, cv_names, samples))
    bpy.ops.object.mode_set(mode="OBJECT")

    for n in driven:
        source, target = rig.pose.bones[n], rig.pose.bones[base[n]]
        target.rotation_mode = source.rotation_mode
        target.matrix_basis = source.matrix_basis.copy()
        for key in source.keys():
            target[key] = source[key]
        for c in source.constraints:
            copied = _copy_constraint(c, target)
            if getattr(copied, "target", None) == rig and getattr(copied, "subtarget", "") in base:
                copied.subtarget = base[copied.subtarget]
    for curve in original_drivers:
        match = re.match(r'pose\.bones\["([^"\\]+)"\]', curve.data_path)
        if match and match[1] in base:
            _copy_driver(rig, curve, curve.data_path.replace(
                f'pose.bones["{match[1]}"]', f'pose.bones["{base[match[1]]}"]', 1))
    for pose in rig.pose.bones:
        if pose.name in driven or pose.name in base.values():
            continue
        for c in pose.constraints:
            if getattr(c, "target", None) == rig and getattr(c, "subtarget", "") in base:
                c.subtarget = base[c.subtarget]
    for curve in original_drivers:
        for var in curve.driver.variables:
            for target in var.targets:
                if target.id == rig and target.bone_target in base:
                    target.bone_target = base[target.bone_target]

    def skin(owner, weights):
        c = owner.constraints.new("ARMATURE")
        c.name = "AS_Bendy_Bind"
        c.use_deform_preserve_volume = False
        for name, weight in weights:
            t = c.targets.new()
            t.target, t.subtarget, t.weight = rig, name, weight

    for name, (root, end, t, offset) in control_info.items():
        skin(rig.pose.bones[offset], [(base[root], 1.0)])
        # Translation follows the segment endpoints, independently of the
        # endpoint's swing rotation (a wrist rotation must not orbit the mid).
        _constraint(rig.pose.bones[offset], "COPY_LOCATION", rig, base[root], "AS_Bendy_FollowStart")
        follow = _constraint(rig.pose.bones[offset], "COPY_LOCATION", rig, base[end], "AS_Bendy_FollowEnd")
        follow.influence = t
        p = rig.pose.bones[name]
        p.rotation_mode = "XYZ"
        p.custom_shape = api._create_control_widget(context.scene, records[name], name,
            api._control_widget_rest_matrix(rig, p.bone))
        p.use_custom_shape_bone_size = False
        color = records[name].get("color", [.2, .6, .8, 1])[:3]
        p.color.palette = "CUSTOM"
        p.color.custom.normal = color
        p.color.custom.select = (1.0, .6, .2)
        p.color.custom.active = (1.0, .8, .3)
    # Junction control is a child of its segment's start control.
    # Use Child Of with a bind inverse to preserve the authored rest matrix.
    for name, (root, end, t, offset) in control_info.items():
        if name.startswith("BendMid"):
            stem, side = root.rsplit("_", 1)
            start = f"Bend{stem}0_{side}"
            if start in control_info:
                owner = rig.pose.bones[offset]
                for constraint in list(owner.constraints):
                    owner.constraints.remove(constraint)
                skin(owner, [(start, 1.0)])

    # The incoming segment owns the end tangent's orientation. Following the
    # outgoing elbow/knee rotation here bends an otherwise straight segment
    # merely by posing IK. Only the junction's animator delta is added.
    for handle, root, finish in end_handles:
        owner = rig.pose.bones[handle]
        skin(owner, [(base[root], 1.0)])
        _constraint(owner, "COPY_LOCATION", rig, finish, "AS_Bendy_EndPosition")
        if finish in control_info:
            c = _constraint(owner, "COPY_ROTATION", rig, finish, "AS_Bendy_EndDelta")
            c.owner_space = c.target_space = "LOCAL"
            c.mix_mode = "ADD"

    context.view_layer.update()
    collection = api._get_or_create_scene_collection(context.scene, "Bendy Curves")

    def make_curve(label, points, weights, cv_names):
        for cv, w in zip(cv_names, weights):
            skin(rig.pose.bones[cv], w)
        curve_data = bpy.data.curves.new("AS_Bendy_" + label, "CURVE")
        curve_data.dimensions = "3D"
        curve_data.resolution_u = 32
        curve_data.path_duration = 100
        curve_data.use_path = True
        spline = curve_data.splines.new("NURBS")
        spline.points.add(len(points)-1)
        spline.order_u = 4
        spline.use_endpoint_u = True
        for point, location in zip(spline.points, points):
            point.co = (*location, 1.0)
        obj = bpy.data.objects.new(curve_data.name, curve_data)
        collection.objects.link(obj)
        obj.parent = rig
        obj.matrix_parent_inverse = Matrix.Identity(4)
        obj.matrix_basis = Matrix.Identity(4)
        obj.hide_render = True
        obj.hide_set(True)
        obj["advanced_skeleton_role"] = "BENDY_CURVE"
        obj["as_import_session_id"] = api._current_import_session_id(context.scene)
        for i, cv in enumerate(cv_names):
            hook = obj.modifiers.new(cv, "HOOK")
            hook.object, hook.subtarget = rig, cv
            hook.vertex_indices_set([i])
            hook.matrix_inverse = rig.data.bones[cv].matrix_local.inverted()
        return obj

    for root, mids, points, weights, helpers in secondary:
        obj = make_curve("Master_" + root, points, weights, helpers)
        for name in mids:
            sample = rig.pose.bones["MCH_BendyMasterPath_" + name]
            c = sample.constraints.new("FOLLOW_PATH")
            c.target = obj
            c.use_fixed_location = True
            c.offset_factor = control_info[name][2]
            _constraint(rig.pose.bones[control_info[name][3]], "COPY_LOCATION", rig,
                        sample.name, "AS_Bendy_MasterFollow")

    for root, parts, end, points, weights, cv_names, samples in curves:
        obj = make_curve(root, points, weights, cv_names)
        a, z = rest[root].translation, rest[end].translation
        for n, sample in zip([root, *parts, end], samples):
            c = rig.pose.bones[sample].constraints.new("FOLLOW_PATH")
            c.name = "AS_Bendy_Path"
            c.target = obj
            c.use_fixed_location = True
            c.use_curve_follow = False
            c.offset_factor = max(0.0, min(1.0, (rest[n].translation-a).dot(z-a)/(z-a).length_squared))
        for i, n in enumerate([root, *parts]):
            result = rig.pose.bones["MCH_BendyResult_" + n]
            _constraint(result, "COPY_TRANSFORMS", rig, base[n], "AS_Bendy_TwistInput")
            _constraint(result, "COPY_LOCATION", rig, samples[i], "AS_Bendy_Position")
            direction = rest[n].to_3x3().inverted() @ (rest[[*parts, end][i]].translation-rest[n].translation)
            axis = max(range(3), key=lambda k: abs(direction[k]))
            t = (rest[n].translation-a).dot(z-a)/(z-a).length_squared
            contributions = []
            stem, side = root.rsplit("_", 1)
            start = f"Bend{stem}0_{side}"
            end_stem, end_side = end.rsplit("_", 1)
            finish = f"Bend{end_stem}0_{end_side}"
            if start in control_info:
                contributions.append((start, 1-t))
            if finish in control_info:
                contributions.append((finish, t))
            contributions.append(("Bend"+root, max(0.0, 1-abs(t-.5)*2)))
            mids = [name for name, info in control_info.items() if info[0] == root
                    and re.fullmatch(r"Bend"+re.escape(stem)+r"[1-9]\d*_"+side, name)]
            for name in mids:
                contributions.append((name, max(0.0, 1-abs(t-control_info[name][2])*(len(mids)+1))))
            scale_pose = rig.pose.bones["MCH_BendyScale_" + n]
            scale_pose.rotation_mode = "XYZ"
            twist_driver = scale_pose.driver_add("rotation_euler", 0).driver
            twist_driver.type = "SCRIPTED"
            twist_terms = []
            for j, (name, weight) in enumerate(contributions):
                var = twist_driver.variables.new()
                var.name, var.type = f"r{j}", "TRANSFORMS"
                target = var.targets[0]
                target.id, target.bone_target = rig, name
                target.transform_type = "ROT_X"
                target.transform_space = "LOCAL_SPACE"
                target.rotation_mode = "SWING_TWIST_X"
                twist_terms.append(f"r{j}*{weight!r}")
            twist_driver.expression = "+".join(twist_terms) or "0.0"
            twist = _constraint(result, "COPY_ROTATION", rig, scale_pose.name, "AS_Bendy_ControlTwist")
            twist.owner_space = twist.target_space = "LOCAL"
            twist.use_x, twist.use_y, twist.use_z = True, False, False
            twist.mix_mode = "ADD"
            track = _constraint(result, "DAMPED_TRACK", rig, samples[i+1], "AS_Bendy_AimNext")
            track.track_axis = "TRACK_" + ("NEGATIVE_" if direction[axis] < 0 else "") + "XYZ"[axis]
            for k in range(3):
                driver = scale_pose.driver_add("scale", k).driver
                driver.type = "SCRIPTED"
                terms = ["1.0"]
                if k == axis:
                    # Segment length is measured in world space and divided
                    # by its unbent counterpart, including Main/import scale.
                    for key, pair in (("bent", (samples[i], samples[i+1])),
                                      ("straight", (base[n], base[[*parts, end][i]]))):
                        var = driver.variables.new()
                        var.name, var.type = key, "LOC_DIFF"
                        for target, name in zip(var.targets, pair):
                            target.id, target.bone_target = rig, name
                            target.transform_space = "WORLD_SPACE"
                    terms = ["bent / max(straight, 0.000001)"]
                else:
                    for j, (name, weight) in enumerate(contributions):
                        var = driver.variables.new()
                        var.name, var.type = f"s{j}", "SINGLE_PROP"
                        var.targets[0].id = rig
                        var.targets[0].data_path = f'pose.bones["{name}"].scale[{k}]'
                        terms.append(f"(s{j}-1.0)*{weight!r}")
                driver.expression = "+".join(terms)
            scale = _constraint(result, "COPY_SCALE", rig, scale_pose.name, "AS_Bendy_SegmentScale")
            scale.owner_space = scale.target_space = "LOCAL"
            scale.use_offset = True

    # Replace skin outputs only after every mechanism input is complete.
    for curve in original_drivers:
        if any(curve.data_path.startswith(f'pose.bones["{n}"]') for n in driven):
            rig.animation_data.drivers.remove(curve)
    for n in driven:
        p = rig.pose.bones[n]
        for constraint in list(p.constraints):
            p.constraints.remove(constraint)
        target = "MCH_BendyResult_" + n if rig.pose.bones.get("MCH_BendyResult_" + n) else base[n]
        _constraint(p, "COPY_TRANSFORMS", rig, target, "AS_Bendy_Output")
    visible = api._find_bone_collection(rig.data, "BendSystem")
    mechanism = api._find_bone_collection(rig.data, "Mechanism")
    for b in rig.data.bones:
        if b.name in control_info or b.name.startswith("MCH_Bendy"):
            for group in tuple(b.collections):
                group.unassign(b)
            (visible if b.name in control_info else mechanism).assign(b)
            b.hide = b.name not in control_info
    context.view_layer.update()
    rig["as_bendy_controls"] = list(control_info)
    return len(control_info)
